#include"Mecro.h"
#include"Play.h"

void main()
{
	Play Play;
	Play.GameStart();

}