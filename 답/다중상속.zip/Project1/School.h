#pragma once
#include"Mecro.h"


class School
{
protected:
	int m_iGrade;
	int m_iClass;
	int m_iNumber;
public:
	School();
	void SetSchool();
	void ShowSchool();
	~School();
};

