#include "WordManager.h"



WordManager::WordManager()
{
	m_iCount = 0;
	m_bGameover = false;
	InitWord();
}
void WordManager::InitWord()
{
	string m_strTmpWord[100];

	ifstream Load;
	Load.open("Word.txt");
	if (Load.is_open())
	{
		Load >> m_iCount;
		for (int i = 0; i < m_iCount; i++)
		{
			Load >> m_strTmpWord[i];
		}
		Load.close();
	}
	FirstWord = new SWORD;
	FirstWord->strWord = m_strTmpWord[0];// ù �ܾ ��������ش�.
	FirstWord->x = (rand() % (WIDTH*2) -10 ) +15; //x ��ǥ���� ��������ش�.2-116
	FirstWord->y = 1;
	FirstWord->number = 1;
	FirstWord->WordFlag = true;
	FirstWord->Next = NULL;

	for (int i = 1; i < m_iCount; i++)
	{
		TmpWord = FirstWord;
		while (TmpWord->Next != NULL)
		{
			TmpWord = TmpWord->Next;
		}				
		NewWord = new SWORD; // �ܾ �߰������ش�.
		NewWord->x = (rand() % (WIDTH * 2) - 10) + 15;
		NewWord->y = 1;
		NewWord->strWord = m_strTmpWord[i];
		NewWord->WordFlag = false;
		NewWord->number = i + 1;
		NewWord->Next = NULL;
		TmpWord->Next = NewWord;
	}
}
WordManager::~WordManager()
{
}
