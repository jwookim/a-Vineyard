#include "Interface.h"



Interface::Interface()
{
}

int Interface::StartPage()
{
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	DrawManager.DrawMidText("�ڡڡڡ� ����ġ�� �ڡڡڡ�", WIDTH, HEIGHT*0.3);
	DrawManager.DrawMidText("1. GAME START", WIDTH, HEIGHT*0.5);
	DrawManager.DrawMidText("2. GAME RANK", WIDTH, HEIGHT*0.6);
	DrawManager.DrawMidText("3. GAME EXIT", WIDTH, HEIGHT*0.7);
	return DrawManager.MenuSelectCursor(3, 4, WIDTH / 2 - 5, HEIGHT*0.5);
}
void Interface::GetStory()
{

	ifstream Load;
	Load.open("Story.txt");
	if (Load.is_open())
	{
		Load >> m_iLine;
		for (int i = 0; i < m_iLine; i++)
			getline(Load, m_strStory[i]);
		Load.close();
	}

}
void Interface::ShowStory()
{
	int iH = HEIGHT * 0.3;//���� ������ ���� ����
	GetStory();
	GamePage();
	for (int i = 0; i < m_iLine; i++)
	{
		if (i < 8)
			DrawManager.DrawMidText(m_strStory[i], WIDTH, iH++);
		if (i >= 8)
		{
			iH = HEIGHT * 0.3;
			DrawManager.BoxErase(WIDTH, iH + 9);//�����
			DrawManager.DrawMidText(m_strStory[i - 7], WIDTH, iH);
			DrawManager.DrawMidText(m_strStory[i - 6], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i - 5], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i - 4], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i - 3], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i - 2], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i - 1], WIDTH, iH++);
			DrawManager.DrawMidText(m_strStory[i], WIDTH, iH++);
		}
		Sleep(100);
	}
	DrawManager.gotoxy(WIDTH, (HEIGHT*0.7) + 2);
	RankManager.SetName();
}
void Interface::GamePage()
{
	system("cls");
	DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	YELLOW
	DrawManager.DrawMidText("������������������������������������", WIDTH, HEIGHT*0.7);
	DrawManager.DrawMidText("��                                ��", WIDTH, (HEIGHT*0.7) + 1);
	DrawManager.DrawMidText("��                                ��", WIDTH, (HEIGHT*0.7) + 2);
	DrawManager.DrawMidText("��                                ��", WIDTH, (HEIGHT*0.7) + 3);
	DrawManager.DrawMidText("������������������������������������", WIDTH, (HEIGHT*0.7) + 4);
	ORIGINAL
	ShowLife();
	ShowName();
}
void Interface::ShowLife()
{
	int iTmp = RankManager.GetLife();
	string strLife;
	for (int i = 0; i < iTmp; i++)
		strLife += "��";
	RED
		DrawManager.DrawMidText("          ", 2, HEIGHT + 2);
		DrawManager.DrawMidText("LIFE -> " + strLife, 2, HEIGHT + 2);
	ORIGINAL
}
void Interface::ShowName()
{
	string strName = RankManager.GetName();
	DrawManager.DrawMidText("      ", WIDTH * 2 - 8, HEIGHT + 2);
	DrawManager.DrawMidText("Name -> " + strName, WIDTH * 2 - 8, HEIGHT + 2);
}
Interface::~Interface()
{
}
