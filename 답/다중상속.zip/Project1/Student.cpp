#include "Student.h"



Student::Student()
{
}
void Student::Start()
{
	SetSchool();
	SetPerson();
	ShowSchool();
	ShowPerson();
}

Student::~Student()
{
}
