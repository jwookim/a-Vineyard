#include "Play.h"


Play::Play()
{
}

void Play::GameStart()
{
	while (1)
	{
		switch (InterManager.StartPage())
		{
		case S_START:
			GamePlay();
			break;
		case S_RANK:
			GameRank();
			break;
		case S_EXIT:
			return;
		default:
			break;
		}
	}
}

void Play::GamePlay()
{
	InterManager.ShowStory();
	InterManager.GamePage();
	while (1)
	{
		WordManager.Erase();
		WordManager.Drop();
		WordManager.Draw();
		Sleep(400);
	}
}
void Play::GameRank()
{

}
Play::~Play()
{
}
