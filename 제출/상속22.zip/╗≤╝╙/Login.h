#pragma once
#include"Mecro.h"

#define IDLEN 3
#define PASSWORDLEN 8
#define IDMAX 10

struct ID
{
	string Id;
	string Password;
	string Name;
	int Age;
	string PhonNumber;
	int Mileage;
};

class Login
{
protected: 
	int Id_Count = 0;
	int m_index = 0;
	ID Id_List[IDMAX];
public:

	Login();
	void MainMenu(int Num);
	void Join();
	void SimpleShowID();
	void ShowID();
	void Setstring(string* str, string tmp);
	void Setint(int* num, string tmp);
	void SetID();
	void LoginON();

	~Login();
};

