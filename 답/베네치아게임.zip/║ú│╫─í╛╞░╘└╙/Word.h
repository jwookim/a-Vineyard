#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"Rank.h"

struct SWORD
{
	string strWord; // �ܾ ����� ����
	int x, y; //x,y��ǥ
	bool WordFlag;
	int number;
	SWORD* Next;
};

class Word
{
public:
	MapDraw DrawManager;
	string strTmp;
	SWORD *FirstWord;
	SWORD *NewWord;
	SWORD *TmpWord;
public:
	Word();

	void Draw();
	void Erase();
	void Drop();
	void Live();
	int Die();
	void Release(SWORD* Node);
	~Word();
};

