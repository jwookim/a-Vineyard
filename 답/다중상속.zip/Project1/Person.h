#pragma once
#include"Mecro.h"
class Person
{
protected:
	string m_strSex;
	int m_iAge;
	string m_strName;
public:
	Person();
	void SetPerson();
	void ShowPerson();
	~Person();
};

