#include"Mecro.h"
#include"Student.h"

void main()
{
	Student Stu;
	Stu.Start();
}