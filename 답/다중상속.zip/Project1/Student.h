#pragma once
#include"Mecro.h"
#include"School.h"
#include"Person.h"
class Student : public School, public Person
{
public:
	Student();
	void Start();
	~Student();
};

