#pragma once
#include"Mecro.h"
#include"Login.h"

enum MENU
{
	MENU_COMDETAIL =1,
	MENU_FUNCTION,
	MENU_MEMBERINFO,
	MENU_MEMBERMODIFY,
	MENU_EXIT
};
class Computer : public Login // public���� �α��� Ŭ������ ��ӹ޴´�.

{
private:
	string m_strName;
	string m_strState;
	string m_strGraphic;
	string m_strCpu;
	string m_strMemory;
public:
	Computer();
	void ComDetail();
	void Func_Menu();
	void ComON();
	void Menu();
	~Computer();
};

