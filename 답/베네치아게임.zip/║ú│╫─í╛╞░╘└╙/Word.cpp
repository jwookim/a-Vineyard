#include "Word.h"

Word::Word()
{

}

void Word::Draw()
{
	TmpWord = FirstWord;
	while (TmpWord->WordFlag != false)
	{
		RED
		DrawManager.DrawMidText(TmpWord->strWord, TmpWord->x, TmpWord->y);
		ORIGINAL
		TmpWord = TmpWord->Next;
	}
	if(rand()%3 ==0)
		TmpWord->WordFlag = true;
}
void Word::Erase()
{
	TmpWord = FirstWord;
	while (TmpWord->WordFlag != false)
	{
		int iTmp = TmpWord->strWord.length();
		string str;
		for (int i = 0; i < iTmp; i++)
			str += "��";

		DrawManager.DrawMidText(str, TmpWord->x, TmpWord->y);
		TmpWord = TmpWord->Next;
	}
}
void Word::Drop() // y��ǥ ���� 1�� ���������ش�.
{

	TmpWord = FirstWord;
	while (TmpWord->WordFlag != false)
	{
	TmpWord->y++;
	if(TmpWord->y >=28)
	{
		system("pause");
		cout << "Gameover";
		exit(1);
	}	
	TmpWord = TmpWord->Next;
	}
}

void Word::Live()
{
	
}

int Word::Die()
{
	return 0;
}
void Word::Release(SWORD* Node)
{
	if (Node == NULL)
		return;
	Release(Node->Next);
	delete Node;
}
Word::~Word()
{
	Release(FirstWord);
}
