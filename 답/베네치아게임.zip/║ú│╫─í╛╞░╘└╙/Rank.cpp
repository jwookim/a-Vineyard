#include "Rank.h"



Rank::Rank()
{
	m_strName = "???";
	m_iScore = 0;
	m_iLife = 5;//default value
}
Rank::~Rank()
{
}
