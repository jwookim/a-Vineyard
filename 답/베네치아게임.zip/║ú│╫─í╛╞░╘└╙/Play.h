#pragma once
#include"Mecro.h"
#include"Interface.h"
#include"Rank.h"
#include"WordManager.h"

class Play
{
private:
	Interface InterManager;
	Rank RankManager;
	WordManager WordManager;
public:
	Play();
	void GameStart();
	void GamePlay();
	void GameRank();
	~Play();
};

