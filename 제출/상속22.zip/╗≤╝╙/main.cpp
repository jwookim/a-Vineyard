#include"Mecro.h"
#include"Computer.h"

void main()
{
	Computer Com;
;
	Com.ComON();
}