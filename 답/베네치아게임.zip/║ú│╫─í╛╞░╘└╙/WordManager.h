#pragma once
#include"Mecro.h"
#include"Word.h"

class WordManager : public Word
{
protected:
	int m_iCount;
	bool m_bGameover;
	
public:
	WordManager();
	void InitWord();

	~WordManager();
};

